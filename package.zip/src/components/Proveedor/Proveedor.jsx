import styles from "./Proveedor.module.css";

function Proveedor() {

  return (
    <div>

    </div>
  );
}

export default Proveedor;
