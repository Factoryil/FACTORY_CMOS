import styles from "./Cliente.module.css";

function Cliente() {

  return (
    <div>

    </div>
  );
}

export default Cliente;
