import React, { useState } from 'react';
import styles from './OrdentrabajoInfo.module.css';
import { apiManager } from "../../api/apiManager";

const OrdentrabajoInfo = ({ data, onUpdate }) => {
  console.log(data);
  
  // Estados para la información actual
  const [estadoOT, setEstadoOT] = useState(data.ESTADO);
  const [estadoVehiculo, setEstadoVehiculo] = useState(data.estado_vehiculo);
  const [estadoAutorizacion, setEstadoAutorizacion] = useState(data.AUTORIZACION);
  const [taller, setTaller] = useState(data.TALLER);
  const [responsablePago, setResponsablePago] = useState(data.RESPONSABLE_PAGO);

  // Estado para los contactos (lista de talleres y responsables de pago)
  const [contactos, setContactos] = useState([]);

  // Estados para controlar el modal:
  // modalMode === "" muestra el menú de opciones; "ot", "vehiculo", "taller" o "responsablePago" muestran el modal de edición
  const [mostrarModal, setMostrarModal] = useState(false);
  const [modalMode, setModalMode] = useState("");
  const [tempEstado, setTempEstado] = useState("");

  // Función para obtener la lista de contactos (talleres y responsables de pago)
  const fetchContactos = async () => {
    try {
      const response = await apiManager.contactos();
      console.log(response);
      setContactos(response);
    } catch (error) {
      console.error("Error fetching contactos:", error);
    }
  };

  // Función genérica para actualizar un campo
  const updateField = async (fieldName, value) => {
    const formData = new FormData();
    formData.append(fieldName, value);
    try {
      // Usamos data.ID_OT como identificador de la orden
      const response = await apiManager.updateEstado(data.ID_OT, formData);
      console.log(`${fieldName} actualizado:`, response);
      // Actualizamos el padre para refrescar la información
      if (onUpdate) {
        onUpdate();
      }
    } catch (error) {
      console.error(`Error al actualizar ${fieldName}:`, error);
    }
  };

  // Función para ejecutar la acción adicional cuando la OT se cierra
  const accionAdicionalCerrada = async () => {
    try {
      // Aquí agrega la lógica adicional que necesites.
      // Por ejemplo, llamar a otra API:
      const response = await apiManager.realizarAccionCerrada(data.ID_OT);
      console.log("Acción adicional ejecutada para OT cerrada:", response);
    } catch (error) {
      console.error("Error ejecutando acción adicional para OT cerrada:", error);
    }
  };

  // Abre el modal de edición según el tipo
  const abrirModalEdicion = async (tipo) => {
    setModalMode(tipo);
    setMostrarModal(true);
    if (tipo === "ot") {
      setTempEstado(estadoOT);
    } else if (tipo === "vehiculo") {
      setTempEstado(estadoVehiculo);
    } else if (tipo === "taller" || tipo === "responsablePago") {
      // Si aún no se han cargado los contactos, se obtienen
      if (contactos.length === 0) {
        await fetchContactos();
      }
      if (tipo === "taller") {
        setTempEstado(taller);
      } else {
        setTempEstado(responsablePago);
      }
    }
  };

  // Confirma el cambio desde el modal de edición
  const handleConfirmarCambio = async () => {
    if (modalMode === "ot") {
      // Verificamos que el estado anterior no era "Cerrada" y que se está cambiando a "Cerrada"
      if (estadoOT !== "Cerrada" && tempEstado === "Cerrada") {
        await accionAdicionalCerrada();
      }
      setEstadoOT(tempEstado);
      await updateField("ESTADO", tempEstado);
    } else if (modalMode === "vehiculo") {
      setEstadoVehiculo(tempEstado);
      await updateField("estado_vehiculo", tempEstado);
    } else if (modalMode === "taller") {
      setTaller(tempEstado);
      await updateField("ID_TALLER", tempEstado);
    } else if (modalMode === "responsablePago") {
      setResponsablePago(tempEstado);
      await updateField("ID_CLIENTE", tempEstado);
    }
    cerrarModal();
  };

  // Función para remitir autorización
  const handleRemitirAutorizacion = async () => {
    if (estadoAutorizacion === "Enviada") {
      alert("La autorización ya ha sido enviada.");
    } else {
      const nuevoEstado = "Enviada";
      setEstadoAutorizacion(nuevoEstado);
      await updateField("AUTORIZACION", nuevoEstado);
    }
    cerrarModal();
  };

  // Cierra el modal y resetea el modo
  const cerrarModal = () => {
    setMostrarModal(false);
    setModalMode("");
  };

  // Abre el menú de opciones (modal)
  const abrirModalOpciones = () => {
    setModalMode(""); // muestra menú de opciones
    setMostrarModal(true);
  };

  // Función para ver la información del vehículo en otra pestaña
  const handleVerClick = () => {
    if (data && data.placa) {
      window.open(`/gestion/vehiculos/ver/${data.placa}`, '_blank');
    }
  };

  // Campos para mostrar la información ordenada
  const orderFields = [
    { label: "Orden Trabajo", key: "ID_OT" },
    { label: "Placa", key: "placa" },
    { label: "Odómetro", key: "odometro" },
    { label: "Fecha Registro", key: "FECHA_REGISTRO" },
    { label: "Fecha Orden", key: "FECHA_ORDEN" },
    { label: "Prioridad", key: "prioridad" },
    { label: "Fecha Programada", key: "FECHA_PROGRAMADA" },
    { label: "Autorización", key: "AUTORIZACION" },
    { label: "Observación", key: "observacion" },
    { label: "ID Aprobador", key: "ID_APROBADOR" },
    { label: "Motivo Rechazo", key: "MOTIVO_RECHAZO" },
    { label: "Estado Vehiculo", key: "estado_vehiculo" },
    { label: "Taller", key: "taller" },
    { label: "Responsable de Pago", key: "cliente" }
  ];

  // Función para asignar clase según el estado de la OT
  const getEstadoClass = (estado) => {
    switch (estado) {
      case "Pendiente":
        return styles.pendiente;
      case "En Ejecucion":
        return styles.enEjecucion;
      case "Ejecutado":
        return styles.ejecutado;
      case "Cerrada":
        return styles.cerrada;
      case "Anulado":
        return styles.anulado;
      default:
        return "";
    }
  };

  if (!data) {
    return <div>Cargando información de la orden de trabajo...</div>;
  }

  return (
    <div className={styles['contenedor-info-vehiculo']}>
      <div className={styles['contenedor-info-contenido']}>
        <div className={styles.headerTop}>
          <div className={styles.invoiceNumber}>
            <button onClick={handleVerClick} className={styles.boton_editar1}>
              <i className="fas fa-eye"></i>
            </button>
            {data.placa} Orden trabajo # {data.ID_OT}{" "}
            - <span className={getEstadoClass(estadoOT)}>{estadoOT}</span>
            <button className={styles.moreOptionsButton} onClick={abrirModalOpciones}>
              <i className="fas fa-edit"></i> Editar
            </button>
          </div>
        </div>
        <div className={styles['contenedor-info-contenido-detalles']}>
          {orderFields.map(({ label, key }) => (
            <div className={styles['contenedor-info-contenido-detalles-item']} key={key}>
              <span>{label}</span>
              <span>
                {data[key] !== null && data[key] !== "" ? data[key] : 'Sin información'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {mostrarModal && (
        <div className={styles.modalOverlay} onClick={cerrarModal}>
          <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
            {modalMode === "" ? (
              <>
                <h2>Opciones</h2>
                <ul className={styles.optionsList}>
                  <li onClick={() => abrirModalEdicion("ot")}>Cambiar Estado OT</li>
                  <li onClick={() => abrirModalEdicion("vehiculo")}>Cambiar Estado Vehículo</li>
                  <li onClick={handleRemitirAutorizacion}>Remitir Autorización</li>
                  <li onClick={() => abrirModalEdicion("taller")}>Cambiar Taller</li>
                  <li onClick={() => abrirModalEdicion("responsablePago")}>Cambiar Responsable de Pago</li>
                </ul>
                <button className={styles.closeModalButton} onClick={cerrarModal}>
                  &times;
                </button>
              </>
            ) : (
              <>
                <h2>
                  {modalMode === "ot"
                    ? "Cambiar Estado OT"
                    : modalMode === "vehiculo"
                    ? "Cambiar Estado Vehículo"
                    : modalMode === "taller"
                    ? "Cambiar Taller"
                    : modalMode === "responsablePago"
                    ? "Cambiar Responsable de Pago"
                    : ""}
                </h2>
                <select value={tempEstado} onChange={(e) => setTempEstado(e.target.value)}>
                  {modalMode === "ot" ? (
                    <>
                      <option value="Pendiente">Pendiente</option>
                      <option value="En Ejecucion">En Ejecucion</option>
                      <option value="Ejecutado">Ejecutado</option>
                      <option value="Cerrada">Cerrada</option>
                      <option value="Anulado">Anulado</option>
                    </>
                  ) : modalMode === "vehiculo" ? (
                    <>
                      <option value="Operativo">Operativo</option>
                      <option value="Taller">Taller</option>
                    </>
                  ) : modalMode === "taller" || modalMode === "responsablePago" ? (
                    contactos.map((contacto) => (
                      <option key={contacto.ID_CONTACTOS} value={contacto.ID_CONTACTOS}>
                        {contacto.NOMBRE_COMPLETO}
                      </option>
                    ))
                  ) : null}
                </select>
                <div className={styles.modalButtons}>
                  <button onClick={handleConfirmarCambio}>Confirmar</button>
                  <button onClick={cerrarModal}>Cancelar</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default OrdentrabajoInfo;
